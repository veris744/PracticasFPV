#include "FileUtils.h"

#include<cstdio>

unsigned int OpenFile(const char* _sFileName, const char* _sMode)
{
	errno_t error_code;

	FILE* pFile = nullptr;

	error_code = fopen_s(&pFile, _sFileName, _sMode);
	if (error_code != 0)
	{
		printf("Error abriendo el fichero %s!", _sFileName);
	}
	else
	{
		unsigned int uId = reinterpret_cast<unsigned int>(pFile);
		return uId;
	}
}


void CloseFile(unsigned int _uId)
{
	fclose(reinterpret_cast<FILE*>(_uId));
}

unsigned int ReadFile(unsigned int uId, char* _pBuffer, unsigned int _uBufferSize)
{

}

void WriteFile(unsigned int uId, char* _pBuffer, unsigned int _uBufferSize)
{

}
